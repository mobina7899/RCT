<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StudyPatient extends Model
{
    use HasFactory;

    protected $table = 'study_patient' ;

    protected $fillable = ['study_id' , 'patient_id' , 'block' , 'group'];

    public function patientCats(){
        $this->belongsToMany(PatientCat::class , 'patient_has_cats') ;
    }
}
